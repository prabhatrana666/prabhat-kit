# smart-fetch-kit 🚀

A lightweight and production-ready fetch utility for Node.js and browser apps.

## Features
- Retry failed requests
- Timeout support
- Built-in caching
- Clean error handling

## Installation
```bash
npm install prabhat-kit